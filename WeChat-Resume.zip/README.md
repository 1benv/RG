# WeChat-Resume
微信小程序个人简历

主要文件存在于Page/index/...

![微信截图_20231019194045](https://github.com/GhostZhr1998/WeChat-Resume/assets/67358635/cf21e2cb-c787-4f16-81c2-01c17968af03)
