/** index.js **/
const config = require('../../resume.config.js');

Page({
  data: {
    project: config.project
  },
})